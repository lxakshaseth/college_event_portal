from django.urls import path
from . import views
urlpatterns=[
    path('',views.home,name='home'),
    path('signup/',views.signup,name='signup'),
    path('login/',views.login_view,name='login'),
    path('logout/',views.logout_view,name='logout'),
    path('add/',views.add_event,name='add_event'),
    path('edit/<int:event_id>/',views.edit_event,name='edit_event'),
    path('delete/<int:event_id>/',views.delete_event,name='delete_event'),
    path('event/<int:event_id>/',views.event_detail,name='event_detail'),
    path('event/<int:event_id>/register/',views.register_event,name='register_event'),
    path('my_registrations/',views.my_registrations,name='my_registrations'),
]
