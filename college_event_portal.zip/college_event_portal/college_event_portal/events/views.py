from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.conf import settings
from .models import Event, Registration
from .forms import EventForm

def home(request):
    events=Event.objects.order_by('date')
    return render(request,'events/index.html',{'events':events})

def signup(request):
    if request.method=='POST':
        u=request.POST.get('username'); e=request.POST.get('email'); p=request.POST.get('password')
        if User.objects.filter(username=u).exists():
            messages.error(request,'Username exists')
        else:
            User.objects.create_user(username=u,email=e,password=p)
            messages.success(request,'Account created. Please login.'); return redirect('login')
    return render(request,'events/signup.html')

def login_view(request):
    if request.method=='POST':
        u=request.POST.get('username'); p=request.POST.get('password')
        user=authenticate(request,username=u,password=p)
        if user: login(request,user); return redirect('home')
        messages.error(request,'Invalid credentials')
    return render(request,'events/login.html')

def logout_view(request):
    logout(request); return redirect('home')

@login_required
def add_event(request):
    if not request.user.is_staff: messages.error(request,'Only organizers/staff can create events.'); return redirect('home')
    if request.method=='POST':
        form=EventForm(request.POST)
        if form.is_valid():
            ev=form.save(commit=False); ev.organizer=request.user; ev.save(); messages.success(request,'Event created'); return redirect('home')
    else: form=EventForm()
    return render(request,'events/event_form.html',{'form':form,'title':'Add Event'})

@login_required
def edit_event(request,event_id):
    ev=get_object_or_404(Event,id=event_id)
    if request.user!=ev.organizer and not request.user.is_superuser: messages.error(request,'Not authorized'); return redirect('home')
    if request.method=='POST':
        form=EventForm(request.POST,instance=ev)
        if form.is_valid(): form.save(); messages.success(request,'Event updated'); return redirect('home')
    else: form=EventForm(instance=ev)
    return render(request,'events/event_form.html',{'form':form,'title':'Edit Event'})

@login_required
def delete_event(request,event_id):
    ev=get_object_or_404(Event,id=event_id)
    if request.user!=ev.organizer and not request.user.is_superuser: messages.error(request,'Not authorized'); return redirect('home')
    if request.method=='POST': ev.delete(); messages.success(request,'Event deleted'); return redirect('home')
    return render(request,'events/confirm_delete.html',{'event':ev})

@login_required
def event_detail(request,event_id):
    ev=get_object_or_404(Event,id=event_id)
    registered=Registration.objects.filter(event=ev,student=request.user).exists()
    return render(request,'events/event_detail.html',{'event':ev,'registered':registered})

@login_required
def register_event(request,event_id):
    ev=get_object_or_404(Event,id=event_id)
    if Registration.objects.filter(event=ev,student=request.user).exists():
        messages.info(request,'Already registered'); return redirect('event_detail',event_id=event_id)
    if ev.registration_set.count()>=ev.max_participants:
        messages.error(request,'Event is full'); return redirect('event_detail',event_id=event_id)
    reg=Registration.objects.create(event=ev,student=request.user); messages.success(request,'Registered successfully')
    try:
        sub=f'Registration Confirmed: {ev.title}'; msg=f'Hi {request.user.username},\nYou are registered for {ev.title} on {ev.date}.'
        send_mail(sub,msg,settings.EMAIL_HOST_USER,[request.user.email],fail_silently=True)
        if ev.organizer.email: send_mail(f'New reg: {ev.title}', f'{request.user.username} registered', settings.EMAIL_HOST_USER, [ev.organizer.email], fail_silently=True)
    except: pass
    return redirect('event_detail',event_id=event_id)

@login_required
def my_registrations(request):
    regs=Registration.objects.filter(student=request.user).select_related('event')
    return render(request,'events/my_registrations.html',{'regs':regs})
