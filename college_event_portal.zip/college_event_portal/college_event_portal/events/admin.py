from django.contrib import admin
from .models import Event, Registration
@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display=('title','date','time','venue','organizer','max_participants')
@admin.register(Registration)
class RegAdmin(admin.ModelAdmin):
    list_display=('student','event','registered_on')
