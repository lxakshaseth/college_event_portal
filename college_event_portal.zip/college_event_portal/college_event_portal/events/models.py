from django.db import models
from django.contrib.auth.models import User

class Event(models.Model):
    title=models.CharField(max_length=200)
    description=models.TextField()
    date=models.DateField()
    time=models.TimeField()
    venue=models.CharField(max_length=200)
    max_participants=models.PositiveIntegerField(default=100)
    organizer=models.ForeignKey(User,on_delete=models.CASCADE)

    def __str__(self): return self.title

    @property
    def spots_taken(self): return self.registration_set.count()

class Registration(models.Model):
    student=models.ForeignKey(User,on_delete=models.CASCADE)
    event=models.ForeignKey(Event,on_delete=models.CASCADE)
    registered_on=models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together=('student','event')
    def __str__(self): return f"{self.student.username} -> {self.event.title}"
