College Event Management Portal - README

1. Create MySQL DB & user using create_db_mysql.sql
2. Create venv, install requirements
3. Run migrations and create superuser (AAS / 12345)
4. Run server
