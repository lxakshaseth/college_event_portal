    # Auto-setup helper script. Read before running.
    import os, subprocess, sys
    base = os.path.dirname(os.path.abspath(__file__))
    print('This script helps create venv, install requirements, run migrations and load initial data.')
    venv_dir = os.path.join(base, 'venv')
    if not os.path.isdir(venv_dir):
        subprocess.run(f'python -m venv "{venv_dir}"', shell=True, check=True)
    if os.name == 'nt':
        pip = os.path.join(venv_dir, 'Scripts', 'pip.exe')
        python = os.path.join(venv_dir, 'Scripts', 'python.exe')
    else:
        pip = os.path.join(venv_dir, 'bin', 'pip')
        python = os.path.join(venv_dir, 'bin', 'python')
    print('Installing requirements...')
    subprocess.run(f'"{pip}" install -r requirements.txt', shell=True, check=True)
    print('Running migrations...')
    subprocess.run(f'"{python}" manage.py migrate', shell=True, check=True)
    print('Creating superuser AAS (password 12345) if not exists...')
    cmd = 'from django.contrib.auth import get_user_model;User=get_user_model();u=User.objects.filter(username="AAS").first();import django
if not u:
 User.objects.create_superuser("AAS","aas@gmail.com","12345")'

    tmp = os.path.join(base, '__create_su.py')
    with open(tmp, 'w') as f:
        f.write('import os\nos.environ.setdefault("DJANGO_SETTINGS_MODULE","college_event_portal.settings")\nimport django\ndjango.setup()\n' + cmd)
    subprocess.run(f'"{python}" "{tmp}"', shell=True)
    os.remove(tmp)
    print('Loading initial data (if present)...') 
    subprocess.run(f'"{python}" manage.py loaddata initial_data.json', shell=True)
    print('Setup complete. Run: venv\\Scripts\\activate then python manage.py runserver')
